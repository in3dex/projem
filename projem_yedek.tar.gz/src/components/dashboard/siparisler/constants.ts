// Gösterilecek ve sıralanacak statüler (Önem sırasına göre)
export const ORDER_STATUS_TABS = [
  { value: "all", label: "Tümü" },
  { value: "Created", label: "Oluşturuldu" },
  { value: "Picking", label: "Hazırlanıyor" },
  { value: "Invoiced", label: "Faturalandı" },
  { value: "Shipped", label: "Kargoya Verildi" },
  { value: "Delivered", label: "Teslim Edildi" },
  { value: "Cancelled", label: "İptal Edildi" },
  { value: "UnDelivered", label: "Teslim Edilemedi" },
]; 