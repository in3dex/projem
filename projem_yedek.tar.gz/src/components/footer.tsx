import Link from "next/link";
import { Mail, MapPin, Phone, ExternalLink, Github } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

export function Footer() {
  return (
    <footer className="bg-muted/40 w-full py-8">
      <div className="container mx-auto px-4 md:px-6 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-primary">TrendEntegre</h3>
          <p className="text-sm text-muted-foreground">
            Trendyol entegrasyonunuzla e-ticaret süreçlerinizi otomatikleştirin ve verimliliğinizi artırın.
          </p>
          <div className="flex space-x-3">
            <Button variant="outline" size="sm" className="h-8 gap-2">
              <Github className="h-4 w-4" />
              <span>GitHub</span>
            </Button>
            <Button variant="outline" size="sm" className="h-8 gap-2">
              <ExternalLink className="h-4 w-4" />
              <span>API Docs</span>
            </Button>
          </div>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-bold">Sayfalar</h3>
          <ul className="grid gap-2 text-sm">
            <li>
              <Link href="/" className="hover:text-primary">
                Anasayfa
              </Link>
            </li>
            <li>
              <Link href="/ozellikler" className="hover:text-primary">
                Özellikler
              </Link>
            </li>
            <li>
              <Link href="/fiyatlandirma" className="hover:text-primary">
                Fiyatlandırma
              </Link>
            </li>
            <li>
              <Link href="/iletisim" className="hover:text-primary">
                İletişim
              </Link>
            </li>
            <li>
              <Link href="/giris" className="hover:text-primary">
                Giriş Yap
              </Link>
            </li>
          </ul>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-bold">Kaynaklar</h3>
          <ul className="grid gap-2 text-sm">
            <li>
              <Link href="/dokumanlar" className="hover:text-primary">
                Dokümantasyon
              </Link>
            </li>
            <li>
              <Link href="/sss" className="hover:text-primary">
                SSS
              </Link>
            </li>
            <li>
              <Link href="/blog" className="hover:text-primary">
                Blog
              </Link>
            </li>
            <li>
              <Link href="/destek" className="hover:text-primary">
                Destek
              </Link>
            </li>
            <li>
              <Link href="/hakkimizda" className="hover:text-primary">
                Hakkımızda
              </Link>
            </li>
          </ul>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-bold">İletişim</h3>
          <div className="grid gap-4 text-sm">
            <div className="flex items-start gap-2">
              <MapPin className="h-4 w-4 mt-0.5 text-primary" />
              <span>Ankara, Türkiye</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-primary" />
              <span>+90 555 123 4567</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-primary" />
              <span>info@trendentegre.com</span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-medium">Bültenimize Abone Olun</span>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="E-posta adresiniz"
                  className="h-9"
                />
                <Button size="sm">Abone Ol</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Separator className="my-6" />
      <div className="container mx-auto px-4 md:px-6 text-center text-sm text-muted-foreground">
        <p>© 2024 TrendEntegre. Tüm hakları saklıdır. Trendyol'un resmi bir ürünü değildir.</p>
      </div>
    </footer>
  );
} 