"use client";

import { useState } from "react";
import Link from "next/link";
import { MailIcon, MapPinIcon, PhoneIcon, SendIcon } from "lucide-react";

import { Footer } from "@/components/footer";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from 'sonner';
import { Toaster } from "@/components/ui/sonner";
import { 
  Select,
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

export default function IletisimPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: ""
  });
  
  const [loading, setLoading] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (value: string) => {
    setFormData(prev => ({ ...prev, subject: value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Burada form gönderme işlemi simüle ediliyor
    // Gerçek uygulamada API çağrısı yapılabilir
    setTimeout(() => {
      toast.success("Mesajınız başarıyla gönderildi. En kısa sürede size dönüş yapacağız.");
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: ""
      });
      setLoading(false);
    }, 1500);
  };
  
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">
                  İletişim
                </div>
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Bizimle İletişime Geçin
                </h1>
                <p className="max-w-[85%] mx-auto text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Sorularınız, önerileriniz veya işbirliği talepleriniz için her zaman buradayız
                </p>
              </div>
            </div>
          </div>
        </section>
        
        <section className="w-full py-12 md:py-24">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid gap-10 lg:grid-cols-2">
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4">İletişim Bilgilerimiz</h2>
                  <p className="text-muted-foreground mb-6">
                    Aşağıdaki iletişim kanallarından bize ulaşabilir veya formu doldurarak mesaj gönderebilirsiniz.
                  </p>
                </div>
                
                <div className="grid gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <MailIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Email</h3>
                      <p className="text-sm text-muted-foreground mt-1">info@trendyolentegrasyon.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <PhoneIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Telefon</h3>
                      <p className="text-sm text-muted-foreground mt-1">+90 (212) 123 45 67</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <MapPinIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Adres</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Levent Mahallesi, Büyükdere Caddesi No:123<br />
                        Şişli, İstanbul 34394
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t">
                  <h3 className="font-medium mb-4">Çalışma Saatlerimiz</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="font-medium">Pazartesi - Cuma</p>
                      <p className="text-muted-foreground">09:00 - 18:00</p>
                    </div>
                    <div>
                      <p className="font-medium">Cumartesi</p>
                      <p className="text-muted-foreground">10:00 - 14:00</p>
                    </div>
                    <div className="col-span-2 mt-2">
                      <p className="font-medium">Pazar</p>
                      <p className="text-muted-foreground">Kapalı</p>
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t">
                  <h3 className="font-medium mb-4">Sosyal Medya</h3>
                  <div className="flex gap-4">
                    <Link 
                      href="https://twitter.com" 
                      className="bg-muted hover:bg-muted/80 p-2 rounded-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <svg className="h-5 w-5" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22 4.01C21.05 4.67 19.92 5.08 18.75 5.26C17.75 4.27 16.33 3.89 15 4.25C13.67 4.61 12.66 5.63 12.3 6.96C11.94 8.29 12.32 9.71 13.31 10.71C10.4 10.58 7.71 9.19 5.88 6.92C5.08 8.39 5.38 10.26 6.67 11.3C6.08 11.3 5.51 11.15 5 10.87C5 10.87 5 10.91 5 10.94C5 12.37 6.04 13.6 7.44 13.91C6.9 14.05 6.34 14.08 5.79 14C6.21 15.19 7.31 16 8.58 16.02C7.42 16.97 6 17.47 4.54 17.47C4.21 17.47 3.88 17.45 3.55 17.4C5.03 18.44 6.75 19 8.5 19C15 19 18.54 13.67 18.54 9.02C18.54 8.82 18.53 8.62 18.52 8.43C19.46 7.75 20.25 6.9 20.83 5.91C19.97 6.29 19.06 6.55 18.12 6.66C19.11 6.06 19.84 5.09 20.19 3.92C19.26 4.5 18.22 4.9 17.14 5.12C16.23 4.16 14.96 3.59 13.62 3.59C11.03 3.59 8.93 5.69 8.93 8.28C8.93 8.65 8.97 9.01 9.05 9.36C5.94 9.16 3.22 7.33 1.47 4.62C1.08 5.32 0.87 6.12 0.87 6.96C0.87 8.55 1.62 9.98 2.81 10.81C2.09 10.79 1.4 10.59 0.79 10.25V10.31C0.79 12.59 2.36 14.48 4.48 14.91C4.1 15.01 3.7 15.06 3.29 15.06C3 15.06 2.72 15.03 2.45 14.98C3.01 16.85 4.74 18.18 6.76 18.22C5.15 19.46 3.14 20.18 0.99 20.18C0.66 20.18 0.33 20.16 0 20.12C2.04 21.42 4.46 22.16 7.06 22.16C13.62 22.16 17.69 17.13 17.69 12.81C17.69 12.6 17.69 12.4 17.68 12.19C18.62 11.43 19.43 10.49 20.05 9.44C19.18 9.81 18.26 10.06 17.3 10.17C18.29 9.57 19.03 8.61 19.38 7.46C18.44 8.03 17.4 8.44 16.31 8.65C15.4 7.7 14.13 7.12 12.78 7.12C10.19 7.12 8.09 9.22 8.09 11.81C8.09 12.18 8.13 12.54 8.21 12.89C5.1 12.69 2.38 10.86 0.63 8.15C0.24 8.85 0.03 9.65 0.03 10.49C0.03 12.08 0.78 13.51 1.97 14.34C1.25 14.32 0.56 14.12 0 13.79V13.85C0 16.13 1.57 18.02 3.69 18.45C3.31 18.55 2.91 18.6 2.5 18.6C2.21 18.6 1.93 18.57 1.66 18.52C2.22 20.39 3.95 21.72 5.97 21.76C4.36 23 2.35 23.72 0.2 23.72C-0.13 23.72 -0.46 23.7 -0.79 23.66C1.25 24.96 3.67 25.7 6.27 25.7" fill="currentColor"/>
                      </svg>
                    </Link>
                    <Link 
                      href="https://facebook.com" 
                      className="bg-muted hover:bg-muted/80 p-2 rounded-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <svg className="h-5 w-5" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M24 12.07C24 5.41 18.63 0 12 0C5.37 0 0 5.41 0 12.07C0 18.1 4.39 23.09 10.12 24V15.56H7.08V12.07H10.12V9.41C10.12 6.38 11.91 4.72 14.65 4.72C15.97 4.72 17.34 4.96 17.34 4.96V7.94H15.83C14.34 7.94 13.87 8.87 13.87 9.82V12.07H17.2L16.67 15.56H13.87V24C19.61 23.09 24 18.1 24 12.07Z" fill="currentColor"/>
                      </svg>
                    </Link>
                    <Link 
                      href="https://linkedin.com" 
                      className="bg-muted hover:bg-muted/80 p-2 rounded-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <svg className="h-5 w-5" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.4701 2.00002H3.53006C2.69006 2.00002 2.00006 2.69002 2.00006 3.53002V20.47C2.00006 21.31 2.69006 22 3.53006 22H20.4701C21.3101 22 22.0001 21.31 22.0001 20.47V3.53002C22.0001 2.69002 21.3101 2.00002 20.4701 2.00002ZM8.09006 18.74H5.09006V9.74002H8.09006V18.74ZM6.59006 8.48002C5.65006 8.48002 4.90006 7.73002 4.90006 6.80002C4.90006 5.87002 5.65006 5.12002 6.59006 5.12002C7.52006 5.12002 8.28006 5.87002 8.28006 6.80002C8.28006 7.73002 7.52006 8.48002 6.59006 8.48002ZM18.9101 18.74H15.9101V14.18C15.9101 13.12 15.8901 11.75 14.4301 11.75C12.9501 11.75 12.7301 12.91 12.7301 14.11V18.74H9.73006V9.74002H12.6101V11H12.6501C13.0401 10.27 13.9801 9.50002 15.3701 9.50002C18.4101 9.50002 18.9101 11.42 18.9101 13.98V18.74Z" fill="currentColor"/>
                      </svg>
                    </Link>
                    <Link 
                      href="https://instagram.com" 
                      className="bg-muted hover:bg-muted/80 p-2 rounded-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <svg className="h-5 w-5" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C14.717 2 15.056 2.01 16.122 2.06C17.187 2.11 17.912 2.277 18.55 2.525C19.21 2.779 19.766 3.123 20.322 3.678C20.8305 4.1779 21.224 4.78259 21.475 5.45C21.722 6.087 21.89 6.813 21.94 7.878C21.987 8.944 22 9.283 22 12C22 14.717 21.99 15.056 21.94 16.122C21.89 17.187 21.722 17.912 21.475 18.55C21.2247 19.2178 20.8311 19.8226 20.322 20.322C19.822 20.8303 19.2173 21.2238 18.55 21.475C17.913 21.722 17.187 21.89 16.122 21.94C15.056 21.987 14.717 22 12 22C9.283 22 8.944 21.99 7.878 21.94C6.813 21.89 6.088 21.722 5.45 21.475C4.78233 21.2245 4.17753 20.8309 3.678 20.322C3.16941 19.8222 2.77593 19.2175 2.525 18.55C2.277 17.913 2.11 17.187 2.06 16.122C2.013 15.056 2 14.717 2 12C2 9.283 2.01 8.944 2.06 7.878C2.11 6.812 2.277 6.088 2.525 5.45C2.77524 4.78218 3.1688 4.17732 3.678 3.678C4.17767 3.16923 4.78243 2.77573 5.45 2.525C6.088 2.277 6.812 2.11 7.878 2.06C8.944 2.013 9.283 2 12 2ZM12 7C10.6739 7 9.40215 7.52678 8.46447 8.46447C7.52678 9.40215 7 10.6739 7 12C7 13.3261 7.52678 14.5979 8.46447 15.5355C9.40215 16.4732 10.6739 17 12 17C13.3261 17 14.5979 16.4732 15.5355 15.5355C16.4732 14.5979 17 13.3261 17 12C17 10.6739 16.4732 9.40215 15.5355 8.46447C14.5979 7.52678 13.3261 7 12 7ZM18.5 6.75C18.5 6.41848 18.3683 6.10054 18.1339 5.86612C17.8995 5.6317 17.5815 5.5 17.25 5.5C16.9185 5.5 16.6005 5.6317 16.3661 5.86612C16.1317 6.10054 16 6.41848 16 6.75C16 7.08152 16.1317 7.39946 16.3661 7.63388C16.6005 7.8683 16.9185 8 17.25 8C17.5815 8 17.8995 7.8683 18.1339 7.63388C18.3683 7.39946 18.5 7.08152 18.5 6.75ZM12 9C12.7956 9 13.5587 9.31607 14.1213 9.87868C14.6839 10.4413 15 11.2044 15 12C15 12.7956 14.6839 13.5587 14.1213 14.1213C13.5587 14.6839 12.7956 15 12 15C11.2044 15 10.4413 14.6839 9.87868 14.1213C9.31607 13.5587 9 12.7956 9 12C9 11.2044 9.31607 10.4413 9.87868 9.87868C10.4413 9.31607 11.2044 9 12 9Z" fill="currentColor"/>
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
              
              <div>
                <form onSubmit={handleSubmit} className="space-y-6 bg-card p-6 rounded-lg shadow-sm">
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold">Bize Mesaj Gönderin</h2>
                    <p className="text-sm text-muted-foreground">
                      Formu doldurarak bize mesaj gönderebilirsiniz. En kısa sürede size dönüş yapacağız.
                    </p>
                  </div>
                  
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">Adınız Soyadınız</Label>
                      <Input 
                        id="name" 
                        name="name" 
                        placeholder="Adınız Soyadınız" 
                        required 
                        value={formData.name}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Adresiniz</Label>
                      <Input 
                        id="email" 
                        name="email" 
                        type="email" 
                        placeholder="ornek@email.com" 
                        required 
                        value={formData.email}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefon Numaranız</Label>
                      <Input 
                        id="phone" 
                        name="phone" 
                        placeholder="0500 000 00 00" 
                        value={formData.phone}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">Konu</Label>
                      <Select onValueChange={handleSelectChange} value={formData.subject}>
                        <SelectTrigger>
                          <SelectValue placeholder="Konu seçiniz" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="genel-bilgi">Genel Bilgi</SelectItem>
                          <SelectItem value="satis">Satış Bilgisi</SelectItem>
                          <SelectItem value="teknik-destek">Teknik Destek</SelectItem>
                          <SelectItem value="isbirligi">İşbirliği</SelectItem>
                          <SelectItem value="diger">Diğer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Mesajınız</Label>
                    <Textarea 
                      id="message" 
                      name="message" 
                      placeholder="Mesajınızı buraya yazınız" 
                      rows={5} 
                      required 
                      value={formData.message}
                      onChange={handleChange}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        İşleniyor...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        Gönder <SendIcon className="h-4 w-4" />
                      </span>
                    )}
                  </Button>
                  
                  <p className="text-xs text-muted-foreground text-center mt-4">
                    Formu göndererek <Link href="/gizlilik-politikasi" className="underline hover:text-primary">Gizlilik Politikamızı</Link> kabul etmiş olursunuz.
                  </p>
                </form>
              </div>
            </div>
          </div>
        </section>
        
        <section className="w-full py-12 md:py-24 bg-muted/30">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col items-center text-center">
              <div className="space-y-4 max-w-[800px]">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                  Ofisimiz
                </h2>
                <p className="text-muted-foreground md:text-xl">
                  İstanbul'un kalbinde yer alan modern ofisimizde sizleri ağırlamaktan mutluluk duyarız
                </p>
              </div>
              <div className="mt-8 w-full h-[400px] rounded-lg overflow-hidden">
                {/* Google Harita iframe entegrasyonu */}
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3007.9358310750303!2d29.006849915734316!3d41.07620732398726!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cab7a2a2c3b963%3A0x7671d1b9817b8519!2sLevent%2C%20B%C3%BCy%C3%BCkdere%20Cd.%2C%2034330%20%C5%9Ei%C5%9Fli%2F%C4%B0stanbul!5e0!3m2!1str!2str!4v1652785878659!5m2!1str!2str"
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen 
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Toaster />
    </div>
  );
} 